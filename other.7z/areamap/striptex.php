<?php 
if("cli"!==PHP_SAPI) return;
$ok_cli=true;
if(!isset($argv[1])) $ok_cli=false;

if(!$ok_cli){
  echo "Call: striptex <file.t3d>".PHP_EOL;
  echo "      (outputs to stdout)".PHP_EOL;
  return;
}

$f_in_old=file($argv[1],FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
foreach ($f_in_old as $line){
   $sta_texname=stripos($line,"Texture=");
   if($sta_texname!==false){
     $end_texname=stripos($line,"Flags=");
     $sta_texstr=substr($line,0,$sta_texname+8);
     $end_texstr=substr($line,$end_texname-1);
     echo $sta_texstr."DefaultTexture".$end_texstr.PHP_EOL;
   }else echo $line.PHP_EOL;
}
?>
